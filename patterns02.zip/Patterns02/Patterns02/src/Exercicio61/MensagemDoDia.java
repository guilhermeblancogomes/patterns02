package Exercicio61;

public interface MensagemDoDia {
	/** Imprime. */
	void imprimir();
}
