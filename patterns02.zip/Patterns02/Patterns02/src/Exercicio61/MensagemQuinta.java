package Exercicio61;

public class MensagemQuinta implements MensagemDoDia {
	public void imprimir() {
		System.out.println("Hoje � quinta-feira.");
	}
}
